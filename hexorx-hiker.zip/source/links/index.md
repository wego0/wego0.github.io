---
type: "links"
title: 链接
layout: "links"
noDate: true
comments: false
---
  
一时兴趣，折腾出来这么一个小站。算是个人的随想记录吧。  
知诺小站 http://www.zhinuo.site , 托管在 Coding.net 上，基于 hexo 。  

**知诺备份网址：**  
<a href="http://www.zhinuo.space" target="_blank" rel="external">http://www.zhinuo.space</a> , 托管在 Github 上，主题不同，内容基本相同。  

**知诺 RSS 订阅网址：**  
http://www.zhinuo.space/rss2.xml 或 http://www.zhinuo.site/rss2.xml 。  
RSS （简易信息聚合）阅读器可以更方便的浏览小站文章。  

---------------------------------------

** <font color=green face=微软雅黑 size=4>友站链接：<font> **
** <font color=green face=微软雅黑 size=3.5><a href="http://daheng3.top" target="_blank" rel="external">畅享衡山</a> | 不一样的视界！一个了解大衡山，发现湖湘，窥看海内外的视界平台；一个为“你我他”排忧解难，互助互惠的实在平台。</font> **