---
date: 2015-08-16 14:58:08
comments: true
---

{% blockquote Chris Gardner https://en.wikipedia.org/wiki/The_Pursuit_of_Happyness The Pursuit of Happyness %}
That maybe happiness is something that we can only pursue. And maybe we can actually never have it....no matter what.

{% endblockquote %}

<br>


### <span class="fa fa-info-circle"></span> Profile

{% pullquote right%}
![](/gallery/forbidden-city.jpg)
this part of my life... this little part, is called **`happiness`** 🎁.
{% endpullquote %}


- Bello, guys. I am ： **iTimeTraveler**


 I live in Beijing and work as a software developer. I use this site to blog on different topics that I like and hope you find interesting.


 I'm an Android Developer <span class="fa fa-code"></span> + prefer Python & Golang + interest in AI(Artificial Intelligence) + <span><font color="#4086F5">G</font></span><span><font color="#EB4132">o</font></span><span><font color="#FCBD00">o</font></span><span><font color="#4086F5">g</font></span><span><font color="#31A952">l</font></span><span><font color="#EB4132">e</font></span> radicals（`Golang`+`Docker`+`Kubernetes`+`AngularJS`).

<br>


<!--
### <span class="fa fa-battery-full"></span> Unlocked skills

- Java
- C
- Linux, Vim
- Data Structure & Algorithms
- MySQL, SQLite
- HTML, CSS
- Javascript, jQuery
- Bootstrap
- D3.js
- Git


### <span class="fa fa-battery-three-quarters"></span> Know Something about

- Python (Flask, Jinja, Numpy, Matplotlib)
- Neo4j Database
- PHP
- Golang


### <span class="fa fa-battery-half"></span> Skills being unlocked

- JVM

-->


### <span class="fa fa-share-alt"></span> Social Info

You can reach me by

- <span class="fa fa-envelope-o"></span> : [iTime](mailto:xuewenlong_2008@sina.com)
- <span class="fa fa-github"></span> : [iTimeTraveler](https://github.com/iTimeTraveler)
- <span class="fa fa-google-plus"></span> : [iTimeTraveler](https://plus.google.com/116515515454998359216)




![So, if you got a dream, you gotta protect it.](/gallery/uconstruction.gif)


