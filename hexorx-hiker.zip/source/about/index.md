---
date: 2015-08-16 14:58:08
comments: true
---



### <span class="fa fa-info-circle"></span> Profile

{% pullquote right %}
![](/gallery/campfire.gif)
I am a slow walker, but I never walk backwards.

—— [**Abraham Lincoln**](https://en.wikipedia.org/wiki/Abraham_Lincoln)
{% endpullquote %}


一时兴趣，折腾出来这么一个小站。

主要摘录和学习古文经典，转摘和分享中医文章，以及个人感悟随想。

** 这里，欢迎您分享相关的文章。**   

**知诺备份网址：**  
布袋小知诺 <a href="http://www.zhinuo.site" target="_blank" rel="external">http://www.zhinuo.site</a> , 托管在 Github 上，主题不同，内容基本相同。  


**日新知 RSS 订阅网址：**  
http://www.rixin.site/atom.xml 
 
RSS （简易信息聚合）阅读器可以更方便的浏览小站文章。  





### <span class="fa fa-share-alt"></span> Social Info


- <span class="fa fa-envelope-o"></span> : [wego](mailto:budaig@outlook.com)
- <span class="fa fa-weibo"></span> : [wego](https://weibo.com/budaig)
- <span class="fa fa-github"></span> : [wego](https://github.com/wego0)


---------------------------------------

** <font color=green face=微软雅黑 size=4>友站链接：<font> **
** <font color=green face=微软雅黑 size=3.5><a href="http://www.daheng3.top" target="_blank" rel="external">童畅享</a>优秀少儿动画介绍和感想，少儿教育理念方式方法的转摘，以及身为父母的你我他们的育儿体悟。</font> **